class Packet:
    def __init__(self, array_of_bytes = None):
        if array_of_bytes != None:
            self.type = array_of_bytes[0] >> 4
            self.id = array_of_bytes[0] & 0xF
            self.sequence_number = (array_of_bytes[1] << 8) + array_of_bytes[2]
            self.length = (array_of_bytes[3] << 8) + array_of_bytes[4]
            self.checksum = (array_of_bytes[5] << 8) + array_of_bytes[6]
            self.data = array_of_bytes[7:]

    def generate_packet(self):
        prog
        packet = []

        packet.append((self.type << 4) + self.id)
        packet.append(self.sequence_number >> 8)
        packet.append(self.sequence_number & 0xFF)
        packet.append(self.length >> 8)
        packet.append(self.length & 0xFF)
        packet.append(self.checksum >> 8)
        packet.append(self.checksum & 0xFF)
        for d in self.data:
            print("Generate packet ")
            print(d)
            packet.append(d)

        return bytes(packet)

    def generate_checksum(self):
        packet = self.generate_packet()

        checksumXor = (packet[0] << 8) + packet[1]
        checksumXor ^= (packet[2] << 8) + packet[3]
        checksumXor ^= (packet[4] << 8) + self.data[0]

        data_length = len(self.data)
        for i in range(1, data_length, 2):
            tmp = (self.data[i] << 8)
            if (i+1 < data_length):
                tmp += self.data[i+1]
            checksumXor ^= tmp
        return checksumXor
