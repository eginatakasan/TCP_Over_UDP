# ----- sender.py ------

#!/usr/bin/env python
from packet import Packet
from random import randrange
from socket import socket, AF_INET, SOCK_DGRAM
from multiprocessing import Process, Manager
from collections import OrderedDict

import sys
import os

BUFFER_SIZE = 32768


def send_file(host, port, file_name, progress_bar):
    s = socket(AF_INET, SOCK_DGRAM)
    addr = (host, int(port))

    f = open(file_name, "rb")
    
    file_size = os.path.getsize(file_name)
    sent_size = -len(file_name)

    data = file_name.encode('utf-8')
    next_data = data

    sequence = 1
    p = Packet()
    p.id = randrange(1 << 4)

    while (data):
        p.sequence_number = sequence
        p.length = len(data)
        p.data = data
        p.checksum = 0

        if (data == next_data):
            sent_size += p.length
            next_data = f.read(BUFFER_SIZE)
        p.type = 0 if next_data else 2
        p.checksum = p.generate_checksum()

        if (s.sendto(p.generate_packet(), addr)):
            progress_bar[file_name] = sent_size/file_size * 100 // 1

            loading_status = ""
            for f_name, progress in progress_bar.items():
                loading_status += f_name + ": " + str(progress) + "%\t"
            print(loading_status, end="\r")

            s.settimeout(2)
            data, addr = s.recvfrom(BUFFER_SIZE)
            p_recv = Packet(data)
            if (p_recv.id == p.id and p_recv.sequence_number == p.sequence_number and p_recv.type == p.type + 1):
                data = next_data
                sequence += 1

    s.close()
    f.close()


if __name__ == '__main__':
    manager = Manager()

    host = input('Host: ')
    port = int(input('Port: '))
    n = int(input('Number of files: '))
    print('Tekan 1 untuk inputan file berupa nama file')
    print('Tekan 2 untuk inputan file berupa path file')
    
    file_names = []
    processes = []
    progress_bar = manager.dict()
    for i in range(n):
        jenis = int(input('Nomor : '))
        while (jenis !=1 and jenis !=2):
            print('Silahkan ulangi')
            jenis = int(input('Nomor : '))
        if (jenis ==1):              
            file_name = input('Input filename of file #' + str(i+1) + ": ")
            file_names.append(file_name)
            progress_bar[file_name] = 0
        if (jenis ==2):
            path_file = input('Path File : ')
            file_name = os.path.basename(path_file)
            file_names.append(file_name)
            progress_bar[file_name] = 0
        
    for file_name in file_names:
        process = Process(target=send_file, args=(
            host, port, file_name, progress_bar))
        process.start()
        processes.append(process)
    for process in processes:
        process.join()
