# ----- receiver.py -----

#!/usr/bin/env python

from packet import Packet
import socket

import sys
import select

BUFFER_SIZE = 32768 + 7

f = {}

host = "0.0.0.0"
port = int(input('Port: '))
with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
    s.bind((host,port)) 
    data, addr = s.recvfrom(BUFFER_SIZE)
    print("Data : ")
    print(data)
    while (data):
        p = Packet(data)
        if (p.generate_checksum() == p.checksum):
            if (p.id in f):
                print("ID : ")
                print(p.id)
                f[p.id].write(p.data)
            else:
                print("Receiving file", p.data, "...")
                print(p.progress_bar,"%")
                f[p.id] = open(p.data, 'wb')
            

            if (p.type == 2):
                del f[p.id]

            p.data = []
            p.type = p.type + 1
            s.sendto(p.generate_packet(), addr)

            data, addr = s.recvfrom(BUFFER_SIZE)
            print("Akhir")
            print(data)





